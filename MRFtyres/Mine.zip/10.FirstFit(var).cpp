#include<stdio.h>
int main()
{
	int p,n,external=0;
	printf("Enter no of processes,memory blocks");
	scanf("%d %d",&p,&n);
	int process[p],visitProcess[p],memory[n],visited[n],dup[n],index=0;
	printf("Enter process Sizes:\n");
	for(int i=0;i<p;i++)
	{
		scanf("%d",&process[i]);		
		visitProcess[i]=0;
	}
	printf("Enter Block sizes:\n");
	for(int i=0;i<n;i++)
	{
		visited[i]=0;
		scanf("%d",&memory[i]);
		dup[i]=memory[i];
		external+=memory[i];
	}
	for(int i=0;i<p;i++)
	{
		int j;
		for(j=0;j<n;j++)
		{
			if(memory[j]>=process[i])
			{
				printf("Process %d(%d)-Block %d(%d)\n",i,process[i],j,memory[j]);
				visited[j]=1;
				visitProcess[i]=1;
				memory[j]-=process[i];
				break;					
			}
		}
		if(j==n)
		{
			printf("Process %d-Not Allocated\n",i);
		}
	}
	int internal=0;
	for(int i=0;i<n;i++)
	{
		if(visited[i]==1)
		{
			external-=dup[i];
			internal+=memory[i];
		}
	}
	printf("Internal Fragmentation:%d\n",internal);
	for(int i=0;i<p;i++)
	{		
		if(visitProcess[i]==0)
		{
			if(process[i]<=external)
			{
				printf("External Fragmentation:%d",external);
				break;
			}				
		}
	}	
}
