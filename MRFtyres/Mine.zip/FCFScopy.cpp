#include<bits/stdc++.h>
using namespace std;
int mins(int a[],int visited[],int n)
{
	int min=100000,index=-1,i;
	for(i=0;i<n;i++)
	{
		if(a[i]<min && visited[i]!=1)
		{
			index=i;
			min=a[i];
		}			
	}
	return index;
}
int main()
{
	int n,i=0;
	printf("Enter N value:");
	scanf("%d",&n);
	int a[n],b[n],c[n],p[n],tat[n],ct[n],visited[n],wt[n],gt=0;
	for(i=0;i<n;i++)
	{
		printf("Enter ArrivalTime and bursttime(%d):",i+1);
		scanf("%d %d",&a[i],&b[i]);
	}
	for(i=0;i<n;i++)
	{
		int m=mins(a,visited,n);
		visited[m]=1;
		p[i]=m;
		if(a[m]!=gt)
		{
			
			printf("-%d [IDLE] %d",gt,a[m]);
			if(i<1)
			{
				printf("-%d [P1] %d",a[i],b[i]);
				ct[i]=a[i]+b[i];
				gt=ct[i];
			}
			else
			{
				ct[i]=ct[i-1]+b[i];				
				printf("-%d [P%d] %d",a[i],i+1,ct[i]);
				gt=ct[i];
			}
		}	
		else
		{
			if(i<1)
			{
				printf("-%d [P1] %d",a[i],b[i]);
				ct[i]=a[i]+b[i];
				gt=ct[i];
			}
			else
			{
				ct[i]=ct[i-1]+b[i];
				printf("-%d [P%d] %d",a[i],i+1,ct[i]);
				gt=ct[i];
			}
		}
	}
}

