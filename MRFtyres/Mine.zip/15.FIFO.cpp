#include<bits/stdc++.h>
using namespace std;
void showq(queue<char>temp){
	cout<<"\t";
	while(!temp.empty()){
		cout<<temp.front()<<" ";
		temp.pop();
	}
}
bool finder(int a,queue<char>temp){
	while(!temp.empty()){
		if(temp.front()==a)
			return true;
		temp.pop();
	}
	return false;
}
int main()
{
	queue<char>q;
	string s;
	int n=0,hit_count=0,miss_count=0;
	cout<<"Enter Frame size"<<endl;
	cin>>n;
	cout<<"ENTER REFERENCE STRING"<<endl;
	cin>>s;
	for(int i=0;i<s.size();i++){
		cout<<s[i]<<":";
		if(finder(s[i],q)){
			showq(q);
			hit_count++;
			cout<<"\tHIT"<<endl;
		}
		else {
			miss_count++;
			if(q.size()<n)
				q.push(s[i]);
			else{
				q.pop();
				q.push(s[i]);
			}
			showq(q);
			cout<<"\tMISS"<<endl;
		}
	}
	cout<<"No of Page faults:"<<miss_count<<endl;
	cout<<"No of Hits:"<<hit_count<<endl;	
}
