#include<stdio.h>
int findindex(int process[],int memory[],int visited[],int k,int n)
{
	int min=0;
	int ind=-1;
	for(int i=0;i<n;i++)
	{
		if(min<memory[i] && memory[i]>=process[k] && visited[i]!=1)
		{
			min=memory[i];
			ind=i;	
		}	
	}
	return ind;
}
int main()
{
	int p,n;
	printf("Enter no of processes,memory blocks");
	scanf("%d %d",&p,&n);
	int process[p],memory[n],visitProcess[p];
	int visited[n],external=0,internal=0;
	printf("Enter process Sizes:\n");
	for(int i=0;i<p;i++)
	{
		scanf("%d",&process[i]);
	}
	printf("Enter Block sizes:\n");
	for(int i=0;i<n;i++)
	{
		visited[i]=-1;
		scanf("%d",&memory[i]);
		external+=memory[i];
	}
	for(int i=0;i<p;i++)
	{
		int j=findindex(process,memory,visited,i,n);
		if(j==-1)
		{
			printf("Process %d(%d)-Not Allocated\n",i,process[i]);
		}
		else
		{
			printf("Process %d(%d)-Block %d(%d)\n",i,process[i],j,memory[j]);
			internal+=(memory[j]-process[i]);
			visited[j]=1;
			visitProcess[i]=1;
			external-=memory[j];			
		}
	}	
	printf("Internal Fragmentation:%d\n",internal);
	for(int i=0;i<p;i++)
	{
		if(visitProcess[i]!=1)
		{
			if(process[i]<=external)
			{
				printf("External Fragmentation:%d",external);
				break;
			}				
		}
	}
}
