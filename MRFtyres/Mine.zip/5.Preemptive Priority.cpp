#include<stdio.h>
int findmin(int at[],int n,int visit[] )
{ 
	int min=10000,index; 
  	int i;
  	for (i=0;i<n;i++)
  	{
	  	if(min>at[i] && visit[i]==0)
	  	{
	  		min=at[i];
	  		index=i;
		}	  
	} 
 	return index;
}
int minpri(int at[],int pri[],int bt[],int n,int st)
{ 
	int i,min=1000;
    for(i=0;i<n;i++)
	{ 
		if( at[i]<=st && bt[i]!=0 )
		{   
			if(pri[i]<=min)
			{ 
				min=pri[i];
		    }
		}
	}	
	return min;
}
int findindex(int at[],int bt[],int pri[],int visit[],int n,int st)
{  
    int i,minindex=1000,min=1000,minarr=1000;
	int flag=0;
	for(i=0;i<n;i++)
	{
		if(pri[i]==minpri(at,pri,bt,n,st)&&minarr>at[i] && at[i]<=st && bt[i]!=0)
		{   
			minarr=at[i];
			minindex=i;
			flag=1;			
		}
	}
	if(flag)
	{
	  	return minindex;	
	}
	else
	{
		return findmin(at,n,visit);
	}
}
int findmin(int at[],int n )
{ 
	int min=10000; 
  	int i;
  	for(i=0;i<n;i++)
  	{
	  	if(min>at[i])
	  	{
	  		min=at[i];
		}	  
  	}  
  	return min;
}
int completed(int bt[],int n)
{
	for(int i=0;i<n;i++)
	{
		if(bt[i]!=0)
		    return 0;
	}
	return 1;
}
int maxar(int at[],int n)
{
	int min=0;
	for(int i=0;i<n;i++)
	{
		if(at[i]>min)
		{
			min=at[i];
		}
	}
	return min;
}
int preemptive_priority(int at[],int bt[],int pri[],int res[],int ct[],int n)
{
	int visit[n],i,st;
    int maxarr=maxar(at,n);	
	for(i=0;i<n;i++)
	{
		visit[i]=0;
	}
	printf("GANNT CHART:\n");
	st=at[findmin(at,n,visit)];
	if(st>0)
	{
		printf("0[IDLE]%d ",st);
	}
	int f=100;	
	while(f--)
	{   
		int a=findindex(at,bt,pri,visit,n,st);		
		visit[a]=1;
		if (at[a]>st)
		{   
			printf("%d[//]%d ",st,at[a]);
			st=at[a];
		}
			printf("%d[P%d]",st,a+1);
			st++;
			bt[a]--;
	    if(maxarr<=st)
	    {
	    	st=st+bt[a];
	    	bt[a]=0;
		}
		printf("%d ",st);
		if(bt[a]==0)
		{
			ct[a]=st;
		}
		else
		{
			visit[a]=0;
		}
		if(completed(bt,n))
		{
			break;
		}
	}
	printf("\n");
}
int main()
{
	int n;
	printf("Enter N value:");
	scanf("%d",&n);
	int i,at[n],bt1[n],bt[n],res[n],pri[n],ct[n],wt[n],tat[n];
    for(i=0;i<n;i++)
    {
    	printf("Enter Priority,ArrivalTime,BurstTime(%d):",i+1);
		scanf("%d %d %d",&pri[i],&at[i],&bt[i]);
    	bt1[i]=bt[i];
	}	
    preemptive_priority(at,bt,pri,res,ct,n);	
    int  total_waiting=0,turnaround=0;
    for(i=0;i<n;i++)
    {    	
    	tat[i]=ct[i]-at[i];
    	turnaround+=tat[i];    	
	}	
    for(i=0;i<n;i++)
    {    	
    	wt[i]=tat[i]-bt[i];
    	total_waiting+=wt[i];
	} 
	printf("\n\n\n\nP\tAT\tBT\tPriorty\tCT\tTAT\tWT\n");
    for(i=0;i<n;i++)
    { 
		printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n",i,at[i],bt[i],pri[i],ct[i],tat[i],wt[i]);
	}
	float tr=turnaround;
	float tw=total_waiting;	
	printf("AVG turn around time = %f \n",tr/n);
	printf("AVG waiting time= %f \n",tw/n);
}
	

