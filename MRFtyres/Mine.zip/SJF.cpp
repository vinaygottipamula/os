#include<bits/stdc++.h>
using namespace std;
int mins(int a[],int b[],int visited[],int n)
{
	int min=100000,index=-1,i;
	for(i=0;i<n;i++)
	{
		if(a[i]==0 && visited[i]!=1)
			return i;
		if(b[i]<min && visited[i]!=1)
		{
			index=i;
			min=b[i];
		}
			
	}
	return index;
}
int main()
{
	int n,i=0;
	printf("Enter N value:");
	scanf("%d",&n);
	int a[n],b[n],c[n],p[n],tat[n],ct[n],visited[n];
	int wt[n];
	for(i=0;i<n;i++)
	{
		printf("Enter ArrivalTime and bursttime(%d):",i+1);
		scanf("%d %d",&a[i],&b[i]);
	}
	printf("Grantt chart: IDLE->");
	for(i=0;i<n;i++)
	{
		int m=mins(a,b,visited,n);
		visited[m]=1;
		p[i]=m;
		printf("P%d-> ",p[i]+1);
		if(i<1)
		{
			c[i]=a[m]+b[m];
		}
		else
			c[i]=c[i-1]+b[m];
			ct[m]=c[i];
			tat[m]=ct[m]-a[m];
			wt[m]=tat[m]-b[m];
	}
	float sum_wt=0,sum_tat=0;
	printf("\n");
	for(i=0;i<n;i++)
	{
		printf("%d ",c[i]);
		sum_wt+=wt[i];
		sum_tat+=tat[i];		
	}
	printf("\n \n\n\n\nTable:\nat bt ct tat wt\n");
	for(i=0;i<n;i++)
		printf("%d   %d   %d   %d   %d \n",a[i],b[i],ct[i],tat[i],wt[i]);
	
	printf("AVG_WAITING TIME:%d",(sum_wt)/n);
}

