#include<stdio.h>
int findmin(int at[],int n,int visit[] )
{ 
	int min=10000,index; 
	int i;
	for (i=0;i<n;i++)
	{
		if(min>at[i] && visit[i]==0)
	  	{
	  		min=at[i];
	  		index=i;
		}	  
	}  
	return index;
}
int findindex(int at[],int bt[],int visit[],int n,int st)
{ 
    int i,minindex=1000,min=1000,flag=0;
	for(i=0;i<n;i++)
	{
		if(visit[i]==0 && min>bt[i] && at[i]<=st )
		{   
			flag=1;
			minindex=i;
			min=bt[i];
		}
	}
	if(flag)
	{
		return minindex;
	}
	else 
	{
		return findmin(at,n,visit);		
	}
}
int sjf(int at[],int bt[],int res[],int ct[],int n)
{
	int visit[n],i,st;	
	for(i=0;i<n;i++)
	{
		visit[i]=0;
	}
	printf("GANNT CHART:\n");
	st=at[findmin(at,n,visit)];
	if(st>0)
	{
		printf("0[IDLE]%d ",st);
	}	
	for(i=0;i<n;i++)
	{   
		int a;	    
		a=findindex(at,bt,visit,n,st);
		if (at[a]>st)
		{   
			printf("%d[IDLE]%d ",st,at[a]);
			st=at[a];
		}		
		printf("%d[P%d]%d ",st,a+1,st+bt[a]);
		visit[a]=1;
		res[a]=st;
		ct[a]=st+bt[a];
		st=st+bt[a];
	}
}
int main()
{
	int n;
	printf("Enter N value:");
	printf("\n");
	scanf("%d",&n);
	int i,at[n],bt[n],res[n],ct[n],wt[n],tat[n];
	for(i=0;i<n;i++)
	{
		printf("Enter ArrivalTime and bursttime(%d):",i+1);
		scanf("%d %d",&at[i],&bt[i]);	
	}	
    sjf(at,bt,res,ct,n);	
    int total_waiting=0,turnaround=0;
    for(i=0;i<n;i++)
    {    	
    	tat[i]=ct[i]-at[i];
    	turnaround+=tat[i];	
	}
    for(i=0;i<n;i++)
    {    	
    	wt[i]=tat[i]-bt[i];
    	total_waiting+=wt[i];
	}
    printf("\n\n\n\nP\tAT\tBT\tCT\tTAT\tWT\n");
    for(i=0;i<n;i++)
    { 
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",i,at[i],bt[i],ct[i],tat[i],wt[i]);
	}
	float tr=turnaround;
	float tw=total_waiting;
	printf("AVG turn around time = %f \n",tr/n);
	printf("AVG waiting time= %f \n",tw/n);	
}
	

