#include<stdio.h>
int visit[20]={0};
int sequence[20]={0};
int allocation[10][10];
int max[10][10];
int need[10][10];
int work[10];
int count=0;
bool allvisit(int p)
{ 
	for(int i=0;i<p;i++)
	{
		if(visit[i]!=1)
			return false;
	}
	return true;
}
bool issafe(int p,int n)
{
	for(int i=0;i<n;i++)
	{
		if(work[i]<need[p][i])
			return false;
	}
	return true;
}
void print(int p)
{  
	for(int i=0;i<p;i++)
	{
		printf(" %d ",sequence[i]);
	}
	count++;
	printf("\n");
}

int bankers(int p,int n,int pos)
{
	if(pos>=p)
	{
		return 0;  
	}
	int current[n];
	for(int i=0;i<n;i++)
	{
		current[i]=work[i];
	}
	for(int i=0;i<p;i++)
	{  
		if(issafe(i,n))
		{
			if(visit[i]==0)
			{
				sequence[pos]=i;
				visit[i]=1;
				for(int j=0;j<n;j++)
				{
					work[j]=work[j]+allocation[i][j];
				}
				if(allvisit(p))
				{
					print(p);
					bankers(p,n,pos+1);
	  			}  
				else
				{
					bankers(p,n,pos+1);
				}	
				visit[i]=0;
				for(int j=0;j<n;j++)
				{
					work[j]=current[j];
	  			}  
			}
		}
	}
}
int main()
{
	int n,p;
	printf("Enter number of processes & sharable resources:\n");
	scanf("%d %d",&p,&n);
	printf("Enter Allocations:\n");
	for(int i=0;i<p;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&allocation[i][j]);
		}
	}
	printf("Enter Max:\n");
	for(int i=0;i<p;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&max[i][j]);
			need[i][j]=max[i][j]-allocation[i][j];
		}
	}
	printf("need matrix\n");
	for(int i=0;i<p;i++)
	{
		for(int j=0;j<n;j++)
		{
			printf("%d ",need[i][j]);
		}
		printf("\n");
	}
	printf("Enter available:\n");
	for(int i=0;i<n;i++)
	{
		scanf("%d",&work[i]);
	}		
	printf("The possible safe sequences are:\n");
	bankers(p,n,0);
	printf("Count: %d",count);
}
