#include<stdio.h>
int main()
{
	int p,n,external=0,internal=0;
	printf("Enter no of processes,memory blocks");
	scanf("%d %d",&p,&n);
	int process[p],visitProcess[p],memory[n];
	int visited[n],index=0;
	printf("Enter process Sizes:\n");
	for(int i=0;i<p;i++)
	{
		scanf("%d",&process[i]);		
		visitProcess[i]=0;
	}
	printf("Enter Block sizes:\n");
	for(int i=0;i<n;i++)
	{
		visited[i]=0;
		scanf("%d",&memory[i]);
		external+=memory[i];
	}
	for(int i=0;i<p;i++)
	{
		int j;
		for(j=0;j<n;j++)
		{
			if(visited[j]!=1)
			{
				if(memory[j]>=process[i])
				{
					printf("Process %d(%d)-Block %d(%d)\n",i,process[i],j,memory[j]);
					visited[j]=1;
					visitProcess[i]=1;
					internal+=memory[j]-process[i];
					external-=memory[j];
					break;					
				}
			}
		}
		if(j==n)
		{
			printf("Process %d-Not Allocated\n",i);
		}
	}
	printf("Internal Fragmentation:%d\n",internal);
	for(int i=0;i<p;i++)
	{
		if(visitProcess[i]!=1)
		{
			if(process[i]<=external)
			{
				printf("External Fragmentation:%d",external);
				break;
			}				
		}
	}	
}
