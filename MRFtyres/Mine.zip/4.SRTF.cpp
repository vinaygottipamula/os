#include<stdio.h>
int findmin(int at[],int n,int visit[] )
{ 
	int min=10000,index; 
  	int i;
  	for (i=0;i<n;i++)
  	{
	  	if(min>at[i] && visit[i]==0)
	  	{
	  		min=at[i];
	  		index=i;
		}	  
	} 
 	return index;
}
int minfindindex(int at[],int bt[],int min,int n)
{   
	int minarr=1000,index;
	for(int i=0;i<n;i++)
	{
		if(bt[i]==min)
		{
			if(minarr>at[i])
			{ 
				minarr=at[i];
			  	index=i;				
			}
		}		
	}
	return index;	
}
int findindex(int at[],int bt[],int visit[],int n,int st)
{  
    int i,minindex=1000,min=1000,minarr=1000,flag=0;
	for(i=0;i<n;i++)
	{
		if(min>=bt[i] && at[i]<=st &&bt[i]!=0 &&visit[i]==0 )
		{   
			minindex=i;
			min=bt[i];
			flag=1;	
		}
	}
	if(flag)
	{
	   minindex=minfindindex(at,bt,min,n);
	   return minindex;
    }
    else
    {
       	return findmin(at,n,visit);
	}
}
int maxar(int at[],int n)
{
	int min=0;
	for(int i=0;i<n;i++)
	{
		if(at[i]>min)
		{
			min=at[i];
		}
	}
	return min;
}

int completed(int bt[],int n)
{
	for(int i=0;i<n;i++)
	{
		if(bt[i]!=0)
		    return 0;
	}
	return 1;
}
int srtf(int at[],int bt[],int res[],int ct[],int n)
{   
	int maxarr=maxar(at,n);    
	int visit[n],i,st;	
	for(i=0;i<n;i++)
	{
		visit[i]=0;
	}
	printf("GANNT CHART:\n");
	st=at[findmin(at,n,visit)];
	if(st>0)
	{
		printf("0[IDLE]%d ",st);
	}	
	while(1)
	{   
		int a,b;
		a=findindex(at,bt,visit,n,st);		
		visit[a]=1;
		if (at[a]>st)
		{   
			printf("%d[IDLE]%d ",st,at[a]);
			st=at[a];
		}
		printf("%d[P%d]",st,a+1);
		st++;
		bt[a]--;
	    if(maxarr<=st)
	    {
	    	st=st+bt[a];
	    	bt[a]=0;
		}
		printf("%d ",st);
		if(bt[a]==0)
		{
			ct[a]=st;
		}
        else
		{
			visit[a]=0;
		}		
		if(completed(bt,n))
		{
			break;
		}
	}
}
int main()
{
	int n;
	printf("Enter N value:");
	scanf("%d",&n);
	int i,bt1[n],at[n],bt[n],res[n],ct[n],wt[n],tat[n];
    for(i=0;i<n;i++)
    {
    	printf("Enter ArrivalTime and bursttime(%d):",i+1);
		scanf("%d %d",&at[i],&bt[i]);
    	bt1[i]=bt[i];    	
	}	
    srtf(at,bt,res,ct,n);	
    int total_waiting=0,turnaround=0;
    for(i=0;i<n;i++)
    {    	
    	tat[i]=ct[i]-at[i];
    	turnaround+=tat[i];    	
	}	
    for(i=0;i<n;i++)
    {    	
    	wt[i]=tat[i]-bt[i];
    	total_waiting+=wt[i];
	}printf("\n\n\n\nP\tAT\tBT\tCT\tTAT\tWT\n");
    for(i=0;i<n;i++)
    { 
		printf("%d\t%d\t%d\t%d\t%d\t%d\n",i,at[i],bt1[i],ct[i],tat[i],wt[i]);
	}
	float tr=turnaround;
	float tw=total_waiting;
	printf("AVG turn around time = %f \n",tr/n);
	printf("AVG waiting time= %f \n",tw/n);
}
	

