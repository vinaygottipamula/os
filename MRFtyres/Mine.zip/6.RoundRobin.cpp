#include<stdio.h>
#include<stdlib.h>
//roundrobin
//4 3 2 8 3 6 9 3 2 4
struct node{
	int pno;
	int at;
	int bt;
	struct node *next;
};
struct node *front=NULL;
struct node *createnode(int pno,int at,int bt)
{
	struct node *nn;
	nn=(struct node *)malloc(sizeof(struct node));
	nn->pno=pno;
	nn->at=at;
	nn->bt=bt;
	return nn;
}
void readyqueue(int pno,int at,int bt)
{  
	struct node *nn,*temp=front;
	nn=createnode(pno,at,bt);
	if(front==NULL || at<front->at )
	{
		nn->next=front;
		front=nn;
	}
	else
	{
		while(temp->next!=NULL && temp->next->at<=at)
		{
			temp=temp->next;
		}
	 	nn->next=temp->next;
		temp->next=nn;
	}
}

int rr(int at[],int bt[],int ct[],int n,int timequantum)
{   
	for(int i=0;i<n;i++)
    {   
		readyqueue(i,at[i],bt[i]);
	}
	struct node *nn,*temp=front;
    int time=0;
    printf("\n\n");
    while(temp!= NULL)
    { 
		if(temp->at>time)
      	{
      		printf("%d IDLE %d ",time,temp->at);
      		time=temp->at;
	  	}
      	if((temp->bt)>timequantum)
      	{
      		printf(" %d P:%d %d ",time,temp->pno+1,time+timequantum);
      		time=time+timequantum;
      		readyqueue(temp->pno,time,temp->bt-timequantum);
	  	}
	  	else
	  	{
	  		printf(" %d P:%d %d ",time,temp->pno+1,time+temp->bt);
	  		time=time+temp->bt;
	  		ct[temp->pno]=time;
	   }
	  temp=temp->next;    	
	}    
}
int main ()
{
	int n,timequantum;
	printf("Enter no. of processes:\n");
	scanf("%d",&n);
	printf("Enter Time Quantum\n");
	scanf("%d",&timequantum);
	int at[n],bt[n],btt[n],ct[n];
	printf("Enter Arrival times:\n");
	for(int i=0;i<n;i++)
    {
    	scanf("%d",&at[i]);
	}
	printf("Enter Burst times:\n");
	for(int i=0;i<n;i++)
    {
    	scanf("%d",&bt[i]);
    	btt[i]=bt[i];
	}
	rr(at,btt,ct,n,timequantum);
	int total_turnaround_time=0;
	int tat[n];
	for(int i=0;i<n;i++)
	{
		tat[i]=ct[i]-at[i];
		total_turnaround_time+=tat[i];
	}
	int total_waiting_time;
	int wt[n];
	for(int i=0;i<n;i++)
	{
		wt[i]=tat[i]-bt[i];
		total_waiting_time+=wt[i];
	}
	printf("\n\n\nProcess\t\tat\tbt\tct\ttat\twt\n");
	for(int i=0;i<n;i++)
	{
	  printf("Process:%d\t%d\t%d\t%d\t%d\t%d\n",i+1,at[i],bt[i],ct[i],tat[i],wt[i]);	
	}
	
	printf("Total TAT:%d\tAVG TAT:%.3f\n",total_turnaround_time,float(total_turnaround_time)/float(n));
	printf("Total WT:%d\tAVG WT:%.3f\n",total_waiting_time,float(total_waiting_time)/float(n));
}
