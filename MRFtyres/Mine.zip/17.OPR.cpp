#include<stdio.h>
int index(int pos,char temp[],char m[],int n){
	int visited[10];
	for(int k=0;k<10;k++){
		visited[k]=-1;
	}
	int indexVal=-1;
	for(int j=pos;temp[j]!='\0';j--){
		for(int i=0;i<n;i++){
			if(m[i]==temp[j] && visited[m[i]-'0']!=1)
			{
				visited[m[i]-'0']=1;
				indexVal=i;
			}
		}
	}
	return indexVal;	
}

bool finder(char temp[],char a,int n)
{
	for(int i=0;i<n;i++){
		if(temp[i]==a)
			return true;
	}
	return false;
}
void showv(char temp[],int n){
	for(int i=0;i<n;i++){
		printf("%c	 ",temp[i]);
	}
}
int main(){
	int n=0,hit_count=0,miss_count=0,ind=0;
	printf("Enter Frame size\n");
	scanf("%d",&n);
	char v[n],s[100];
	for(int i=0;i<n;i++){
		v[i]='-';
	}
	printf("ENTER REFERENCE STRING:\n");
	scanf("%s",&s);
	for(int i=0;s[i]!='\0';i++){
		printf("%c: ",s[i]);
		if(finder(v,s[i],n)){
			showv(v,n);
			hit_count++;
			printf("\tHIT\n");
		}
		else {
			miss_count++;
			if(ind<n)
				v[ind++]=s[i];
			else{
				v[index(i,s,v,n)]=s[i];
			}
			showv(v,n);
			printf("\tMISS\n");
		}
	}
	printf("No of Page faults: %d\n",miss_count);
	printf("No of Hits: %d\n",hit_count);
}
