#include<stdio.h>
int findindex(int process[],int memory[],int k,int n)
{
	int min=100000;
	int ind=-1;
	for(int i=0;i<n;i++)
	{
		if(min>memory[i] && memory[i]>=process[k])
		{
			min=memory[i];
			ind=i;	
		}	
	}
	return ind;
}
int main()
{
	int p,n;
	printf("Enter no of processes,memory blocks");
	scanf("%d %d",&p,&n);
	int process[p],visitProcess[p],memory[n],visited[n],dup[n],external=0,internal=0;
	printf("Enter process Sizes:\n");
	for(int i=0;i<p;i++)
	{
		scanf("%d",&process[i]);
	}
	printf("Enter Block sizes:\n");
	for(int i=0;i<n;i++)
	{
		visited[i]=-1;
		scanf("%d",&memory[i]);
		external+=memory[i];
		dup[i]=memory[i];
	}
	
	for(int i=0;i<p;i++)
	{
		int j=findindex(process,memory,i,n);
		if(j==-1)
		{
			printf("Process %d(%d)-Not Allocated\n",i,process[i]);
		}
		else
		{
			printf("Process %d(%d)-Block %d(%d)\n",i,process[i],j,memory[j]);
			visited[j]=1;
			visitProcess[i]=1;
			external-=memory[j];
			memory[j]-=process[i];			
		}
	}		
	for(int i=0;i<n;i++)
	{
		if(visited[i]==1)
		{
			external-=dup[i];
			internal+=memory[i];
		}
	}
	printf("Internal Fragmentation:%d\n",internal);
	for(int i=0;i<p;i++)
	{
		if(visitProcess[i]!=1)
		{
			if(process[i]<=external)
			{
				printf("External Fragmentation:%d",external);
				break;
			}				
		}
	}
}
