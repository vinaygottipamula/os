#include<stdio.h>
int findmin(int at[],int n,int visit[] )
{ 
	int min=10000,index; 
  	int i;
  	for (i=0;i<n;i++)
  	{
	  	if(min>at[i] && visit[i]==0)
	  	{
	  		min=at[i];
	  		index=i;
		}	  
	} 
 	return index;
}
int minpri(int at[],int pri[],int visit[],int n,int st)
{ 
	int i,min=1000;
    for(i=0;i<n;i++)
	{ 
		if(visit[i]==0 && at[i]<=st )
		{   
			if(pri[i]<=min)
			{ 
				min=pri[i];
		    }
		}
	}	
	return min;
}
int findindex(int at[],int bt[],int pri[],int visit[],int n,int st)
{  
    int i,minindex=1000,min=1000,minarr=1000,flag=0;
	for(i=0;i<n;i++)
	{
		if(visit[i]==0 && pri[i]==minpri(at,pri,visit,n,st)&&minarr>at[i] && at[i]<=st )
		{   
			minarr=at[i];
			minindex=i;
			flag=1;			
		}
	}
	if(flag)
	{
		return minindex;
	}
	else 
	{
		return findmin(at,n,visit);
	}
}
int priority(int at[],int bt[],int pri[],int res[],int ct[],int n)
{
	int visit[n],i,st;	
	for(i=0;i<n;i++)
	{
		visit[i]=0;
	}
	printf("GANNT CHART:\n");
	st=at[findmin(at,n,visit)];
	if(st>0)
	{
		printf("0[IDLE]%d ",st);
	}	
	for(i=0;i<n;i++)
	{   
		int a;	    
		a=findindex(at,bt,pri,visit,n,st);
		if (at[a]>st)
		{   
			printf("%d[IDLE]%d ",st,at[a]);
			st=at[a];
		}		
		printf("%d[P%d]%d ",st,a+1,st+bt[a]);
		visit[a]=1;
		res[a]=st;
		ct[a]=st+bt[a];
		st=st+bt[a];
	}
}
int main()
{
	int n;
	printf("Enter N value:");
	scanf("%d",&n);
	int i,at[n],bt[n],res[n],pri[n],ct[n],wt[n],tat[n];
	for(i=0;i<n;i++)
	{
		printf("Enter ArrivalTime,BurstTime,Priority(%d):",i+1);
		scanf("%d %d %d",&at[i],&bt[i],&pri[i]);
	}	
    priority(at,bt,pri,res,ct,n);	
    int total_waiting=0,turnaround=0;
    for(i=0;i<n;i++)
    {    	
    	tat[i]=ct[i]-at[i];
    	turnaround+=tat[i];    	
	}	
    for(i=0;i<n;i++)
    {
    	wt[i]=tat[i]-bt[i];
    	total_waiting+=wt[i];
	}    
    printf("\n\n\n\nP\tAT\tBT\tPriorty\tCT\tTAT\tWT\n");
    for(i=0;i<n;i++)
    { 
		printf("%d\t%d\t%d\t%d\t%d\t%d\t%d\n",i,at[i],bt[i],pri[i],ct[i],tat[i],wt[i]);
	}
	float tr=turnaround;
	float tw=total_waiting;
	printf("AVG turn around time = %f \n",tr/n);
	printf("AVG waiting time= %f \n",tw/n);
}

