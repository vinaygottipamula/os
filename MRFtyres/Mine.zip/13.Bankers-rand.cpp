#include<stdio.h>
#include<stdlib.h>
int finished(int finish[],int m)
{
	for(int i=0;i<m;i++)
	{
		if(finish[i]==0)
			return 0;
	}
	return 1;
}
int needy(int need[],int work[],int n)
{
	for(int i=0;i<n;i++)
	{
		if(need[i]>work[i])
			return 0;
	}
	return 1;
}
void bankers(int m,int n,int all[][100],int need[][100],int work[],int finish[],int p[],int index)
{
	int i=rand()%5;
	printf("%d\n",i);
		if(finish[i]==0 && needy(need[i],work,n))
		{
			for(int j=0;j<n;j++)
			{
				work[j]+=all[i][j];
			}
			p[index++]=i;
			finish[i]=1;
		}
	if(finished(finish,m))
	{
		for(int i=0;i<m;i++)
		{
			printf("%d-",p[i]);				
		}
	}
	else		
		bankers(m,n,all,need,work,finish,p,index);
		
}
int main()
{
	int m,n,index=0;
	printf("Enter number of processes & sharable resources:\n");
	scanf("%d %d",&m,&n);
	int all[m][100],max[m][n],need[m][100],finish[m],p[m];
	printf("Enter Allocations:\n");
	for(int i=0;i<m;i++)
	{
		finish[i]=0;
		for(int j=0;j<n;j++)
		{
			scanf("%d",&all[i][j]);
		}
	}
	printf("Enter Max:\n");
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			scanf("%d",&max[i][j]);
		}
	}
	printf("Need Matrix:\n");
	for(int i=0;i<m;i++)
	{
		for(int j=0;j<n;j++)
		{
			need[i][j]=max[i][j]-all[i][j];
			printf("%d ",need[i][j]);
		}
		printf("\n");
	}
	printf("Enter available:\n");
	int available[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&available[i]);
	}
	bankers(m,n,all,need,available,finish,p,index);
}
